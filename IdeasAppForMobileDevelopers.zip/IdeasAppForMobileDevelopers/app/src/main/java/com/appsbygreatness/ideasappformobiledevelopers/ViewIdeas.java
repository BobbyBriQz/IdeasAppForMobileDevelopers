package com.appsbygreatness.ideasappformobiledevelopers;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class ViewIdeas extends AppCompatActivity implements IdeaAdapter.OnIdeaClickListener,
        IdeaAdapter.OnLongIdeaClickListener, NavigationView.OnNavigationItemSelectedListener {

    private ArrayList<Idea> ideas;
    private static IdeaAdapter ideaAdapter;
    SharedPreferences preferences;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    TextView drawerUsername, drawerAppCount;
    View headerView;
    NavigationView navigationView;

    private static final String TAG = "ViewIdeas";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_ideas);

        Toolbar appbar = findViewById(R.id.appBar);
        setSupportActionBar(appbar);

        drawerLayout = findViewById(R.id.drawerLayout);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open,R.string.close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        navigationView = findViewById(R.id.navView);

        navigationView.setNavigationItemSelectedListener(this);

        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);


        setupPreferences();

        ideaAdapter = new IdeaAdapter(this, ideas, this, this);

        recyclerView.setAdapter(ideaAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), NewIdea.class);
                startActivityForResult(intent, 2);
            }
        });



        NavigationView navigationView = findViewById(R.id.navView);
        headerView = navigationView.getHeaderView(0);

        drawerUsername = headerView.findViewById(R.id.drawerUserName);
        drawerUsername.setText(preferences.getString("Username", ""));

        updateHeaderAppCount();

    }

    public void updateHeaderAppCount(){

        drawerAppCount = headerView.findViewById(R.id.drawerAppsCount);
        drawerAppCount.setText(new StringBuilder().append("Currently working on ").append(ideas.size()).append(" apps."));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == NewIdea.NEW_IDEAS_RESULTCODE ){

            ideaAdapter.notifyDataSetChanged();

        }else if(resultCode == DetailedPage.DETAILED_PAGE_RESULTCODE ){

            ideaAdapter.notifyDataSetChanged();

        }


    }

    @Override
    protected void onResume() {
        super.onResume();

        updateHeaderAppCount();

        ideaAdapter.notifyDataSetChanged();
    }

    @Override
    public void onIdeaClick(int position) {

        Intent intent = new Intent(getApplicationContext(), DetailedPage.class);

        intent.putExtra("Position", position);

        startActivityForResult(intent, 9);


    }
    @Override
    public void onLongIdeaClick(final int position) {
        //Set up functionality to delete

        new AlertDialog.Builder(this)
                .setTitle("Delete App Idea")
                .setIcon(R.drawable.ic_delete)
                .setMessage("Are you sure you want to delete "+ ideas.get(position).getName() + "?")
                .setNegativeButton("No", null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ideas.remove(position);



                        Toast.makeText(getApplicationContext(),
                                 " App idea deleted",
                                Toast.LENGTH_SHORT).show();

                        updateHeaderAppCount();


                        ideaAdapter.notifyDataSetChanged();
                    }
                }).show();


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        savePreferences();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //code that inflates searchView for Toolbar
        getMenuInflater().inflate(R.menu.view_ideas_menu, menu);


        //set up code for search functionality
        MenuItem searchItem = menu.findItem(R.id.searchButton);

        //SearchManager searchManager = (SearchManager) IdeaList.this.getSystemService(Context.SEARCH_SERVICE);

        SearchView searchView = null;

        if (searchItem != null){

            searchView = (SearchView) searchItem.getActionView();

        }

        searchView.isIconfiedByDefault();


        //Setting up search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

                ViewIdeas.ideaAdapter.getFilter().filter(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                ViewIdeas.ideaAdapter.getFilter().filter(s);
                return false;
            }});


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (drawerToggle.onOptionsItemSelected(item)){

        }


        if (item.getItemId() == R.id.saveApp){

            savePreferences();

        }else if (item.getItemId() == R.id.exitApp){

            savePreferences();

            Intent exit = new Intent(Intent.ACTION_MAIN);
            exit.addCategory(Intent.CATEGORY_HOME);
            exit.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(exit);
        }else if(item.getItemId() == R.id.logout){

            logout();


        }


        return super.onOptionsItemSelected(item);

    }

    public void logout(){

        savePreferences();

        Intent logout = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(logout);

        finish();

    }

    public void savePreferences(){

        SaveInBackground saveInBackground = new SaveInBackground();

        saveInBackground.start();



    }



    public void setupPreferences() {

        preferences = getSharedPreferences(getPackageName(), MODE_PRIVATE);
        ArrayList<Idea> emptyArray = new ArrayList<>();
        Gson gson = new Gson();
        String emptyArrayOfIdeas = gson.toJson(emptyArray);

        if (!preferences.getString("Ideas", emptyArrayOfIdeas).equals(emptyArrayOfIdeas)) {


            String json = preferences.getString("Ideas", emptyArrayOfIdeas);

            Type type = new TypeToken<ArrayList<Idea>>(){}.getType();

            ArrayList<Idea> ideasToBeLoaded = gson.fromJson(json, type);

            Singleton.getInstance().loadIdeas(ideasToBeLoaded);

            ideas = Singleton.getInstance().getIdea();

        }else{

            ideas = Singleton.getInstance().getIdea();

            //This adds a single app idea to the list of ideas if the list is empty is empty

            ideas.add(new Idea("Sample App",

                    "This mobile app helps developers document " +
                    "their app ideas while also giving them the ability to write out the " +
                    "core functionalities of the app and also set //todo tasks.",

                    "Display app ideas in list.\n\n" +
                            "App ideas could be added, modifies or deleted with ease.\n\n" +
                            "Images can be imported for individual ideas, this is useful " +
                            "especially in the case of multiple wireframes to be implemented, " +
                            "complex app logic sketches or even UML diagrams\n\n" +
                            "App allows you delete ideas that you have deemed unwanted.",

                    "//Set up listview\n\n" +
                            "Set up search functionality on listview.\n\n" +
                            "Design app logo.\n\n" +
                            "Remember to change font size for textView",

                    null, null, null));

        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {


            if (menuItem.getItemId() == R.id.logoutDrawer){

                logout();

            }else if(menuItem.getItemId() == R.id.changePassword){


            }else if (menuItem.getItemId() == R.id.suggest){


            }else if (menuItem.getItemId() == R.id.aboutDeveloper){

                AboutDeveloper aboutDeveloper = new AboutDeveloper();

                FragmentManager fragmentManager = getSupportFragmentManager();

                fragmentManager.beginTransaction()
                        .add(R.id.fragmentContainer, aboutDeveloper)
                        .commit();

            }else if(menuItem.getItemId() == R.id.rateApp){


            }else if(menuItem.getItemId() == R.id.removeAds){


            }

        return false;

    }

    public class SaveInBackground extends Thread{

        @Override
        public void run() {
            super.run();

            SharedPreferences.Editor editor = preferences.edit();

            Gson gson = new Gson();

            String json = gson.toJson(ideas);

            editor.putString("Ideas", json).apply();


        }
    }



}
