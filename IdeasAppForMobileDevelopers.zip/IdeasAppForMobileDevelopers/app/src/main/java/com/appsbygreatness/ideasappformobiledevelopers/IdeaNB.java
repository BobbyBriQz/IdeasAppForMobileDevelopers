package com.appsbygreatness.ideasappformobiledevelopers;


import java.util.ArrayList;

public class IdeaNB {

    private String name;
    private ArrayList<String> ideaPics ;

    private String idea;
    private String functionality;
    private String todo;
    private String timestamp;

    public IdeaNB(String name, String idea, String functionality, String todo, String timestamp, ArrayList<String> bitmaps) {
        this.name = name;
        this.idea = idea;
        this.functionality = functionality;
        this.todo = todo;
        this.timestamp = timestamp;
        this.ideaPics = new ArrayList<>();

        if(bitmaps != null && bitmaps.size() > 0){

            this.ideaPics = bitmaps;
        }


    }

    public String getIdeaPic(int i) {
        return ideaPics.get(i);
    }

    public ArrayList<String> getIdeaPics() {
        return ideaPics;
    }

    public void addIdeaPic(String ideaPic) {

        this.ideaPics.add(ideaPic);
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdea() {
        return idea;
    }

    public void setIdea(String idea) {
        this.idea = idea;
    }

    public String getFunctionality() {
        return functionality;
    }

    public void setFunctionality(String functionality) {
        this.functionality = functionality;
    }

    public String getTodo() {
        return todo;
    }

    public void setTodo(String todo) {
        this.todo = todo;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }


}
